package com.stephengware.java.planware.logic;

public interface Literal extends Expression {
	
	public Literal negate();
}
