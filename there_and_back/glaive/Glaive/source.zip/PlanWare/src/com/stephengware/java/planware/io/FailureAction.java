package com.stephengware.java.planware.io;

class FailureAction extends RuntimeException {

	private static final long serialVersionUID = 1L;
}
